/**
 * Pacote de exceções do sistema PPGI.
 *
 * @author Tiago da Cruz Santos
 * @author Atílio Antônio Dadalto
 */
package sisPPGI.excecoes;
