/**
 * Pacote contendo as classes e as definições principais do sistema PPGI.
 *
 * @author Tiago da Cruz Santos
 * @author Atílio Antônio Dadalto
 * @version 1.0
 */
package sisPPGI;
